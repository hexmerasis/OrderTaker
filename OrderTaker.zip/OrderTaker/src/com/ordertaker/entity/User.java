package com.ordertaker.entity;

public class User {

}
