package com.ordertaker.service.impl;

public class LoginServiceImpl {

}
