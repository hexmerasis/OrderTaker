package com.ordertaker.service;

public interface LoginService {

}
