package com.ordertaker.dao;

public interface LoginDao {

}
