package com.ordertaker.dao.impl;

public class LoginDaoImpl {

}
