package com.ordertaker.servlet;

public class LoginServlet {

}
